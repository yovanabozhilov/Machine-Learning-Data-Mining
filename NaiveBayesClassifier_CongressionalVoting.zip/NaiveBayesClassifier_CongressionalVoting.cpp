#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <cmath>
#include <algorithm>
#include <iomanip>
#include <random>

constexpr int NUM_ATTRIBUTES = 16;
constexpr int NUM_CLASSES = 2;

enum ClassLabel {
    DEMOCRAT = 0,
    REPUBLICAN = 1
};

enum Vote {
    NO = 0,
    YES = 1,
    ABSTAIN = 2,
    MISSING = -1
};

struct Record {
    ClassLabel classLabel;
    std::vector<Vote> attributes;
};

void fillMissingValues(std::vector<Record>& records) {
    for (int i = 0; i < NUM_ATTRIBUTES; ++i) {
        int count[3] = { 0 };
        for (const auto& record : records) {
            if (record.attributes[i] != MISSING) {
                count[record.attributes[i]]++;
            }
        }

        Vote mostFrequent = YES;
        if (count[NO] > count[mostFrequent]) {
            mostFrequent = NO;
        }
        if (count[ABSTAIN] > count[mostFrequent]) {
            mostFrequent = ABSTAIN;
        }

        for (auto& record : records) {
            if (record.attributes[i] == MISSING) {
                record.attributes[i] = mostFrequent;
            }
        }
    }
}

void readData(const std::string& filename, bool treatMissingAsAbstain, std::vector<Record>& records) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error while opening the file." << std::endl;
        return;
    }

    std::string line;
    while (std::getline(file, line)) {
        std::istringstream stream(line);
        std::string token;

        std::getline(stream, token, ',');
        ClassLabel classLabel = (token == "democrat") ? DEMOCRAT : REPUBLICAN;

        std::vector<Vote> attributes(NUM_ATTRIBUTES);
        for (int i = 0; i < NUM_ATTRIBUTES; ++i) {
            std::getline(stream, token, ',');
            if (token == "y") {
                attributes[i] = YES;
            }
            else if (token == "n") {
                attributes[i] = NO;
            }
            else {
                attributes[i] = treatMissingAsAbstain ? ABSTAIN : MISSING;
            }
        }

        records.push_back({ classLabel, attributes });
    }

    if (!treatMissingAsAbstain) {
        fillMissingValues(records);
    }
}

void stratifiedSplit(const std::vector<Record>& records, std::vector<Record>& train, std::vector<Record>& test, double splitRatio) {
    std::vector<Record> democrats, republicans;

    for (const auto& record : records) {
        if (record.classLabel == DEMOCRAT) {
            democrats.push_back(record);
        }
        else {
            republicans.push_back(record);
        }
    }

    std::random_device rd;
    std::mt19937 g(rd());
    std::shuffle(democrats.begin(), democrats.end(), g);
    std::shuffle(republicans.begin(), republicans.end(), g);

    size_t trainDemocrats = static_cast<size_t>(splitRatio * democrats.size());
    size_t trainRepublicans = static_cast<size_t>(splitRatio * republicans.size());

    train.insert(train.end(), democrats.begin(), democrats.begin() + trainDemocrats);
    train.insert(train.end(), republicans.begin(), republicans.begin() + trainRepublicans);

    test.insert(test.end(), democrats.begin() + trainDemocrats, democrats.end());
    test.insert(test.end(), republicans.begin() + trainRepublicans, republicans.end());
}

void trainNaiveBayes(const std::vector<Record>& train, double probabilities[NUM_CLASSES][NUM_ATTRIBUTES][3], double classProbabilities[NUM_CLASSES], double lambda) {
    int classCounts[NUM_CLASSES] = { 0 };
    int attributeCounts[NUM_CLASSES][NUM_ATTRIBUTES][3] = { 0 };

    for (const auto& record : train) {
        int label = record.classLabel;
        classCounts[label]++;
        for (int i = 0; i < NUM_ATTRIBUTES; ++i) {
            if (record.attributes[i] >= 0 && record.attributes[i] < 3) {
                attributeCounts[label][i][record.attributes[i]]++;
            }
        }
    }

    for (int c = 0; c < NUM_CLASSES; ++c) {
        classProbabilities[c] = (classCounts[c] + lambda) / (train.size() + NUM_CLASSES * lambda);
        for (int i = 0; i < NUM_ATTRIBUTES; ++i) {
            for (int v = 0; v < 3; ++v) {
                probabilities[c][i][v] = (attributeCounts[c][i][v] + lambda) / (classCounts[c] + 3 * lambda);
            }
        }
    }
}

int predict(const Record& record, double probabilities[NUM_CLASSES][NUM_ATTRIBUTES][3], double classProbabilities[NUM_CLASSES]) {
    double logLikelihood[NUM_CLASSES] = { log(classProbabilities[DEMOCRAT]), log(classProbabilities[REPUBLICAN]) };

    for (int c = 0; c < NUM_CLASSES; ++c) {
        for (int i = 0; i < NUM_ATTRIBUTES; ++i) {
            logLikelihood[c] += log(probabilities[c][i][record.attributes[i]]);
        }
    }
    return logLikelihood[DEMOCRAT] > logLikelihood[REPUBLICAN] ? DEMOCRAT : REPUBLICAN;
}

double myAccumulate(const std::vector<double>& vec) {
    double sum = 0.0;
    for (size_t i = 0; i < vec.size(); ++i) {
        sum += vec[i];
    }
    return sum;
}

void crossValidation(const std::vector<Record>& train, int k, double& meanAccuracy, double& stdDev) {
    std::vector<double> accuracies;

    size_t foldSize = train.size() / k;
    for (int i = 0; i < k; ++i) {
        std::vector<Record> foldTrain, foldTest;

        for (size_t j = 0; j < train.size(); ++j) {
            if (j >= i * foldSize && j < (i + 1) * foldSize) foldTest.push_back(train[j]);
            else foldTrain.push_back(train[j]);
        }

        double probabilities[NUM_CLASSES][NUM_ATTRIBUTES][3], classProbabilities[NUM_CLASSES];
        trainNaiveBayes(foldTrain, probabilities, classProbabilities, 1.0); 

        int correct = 0;
        for (const auto& record : foldTest) {
            if (predict(record, probabilities, classProbabilities) == record.classLabel) correct++;
        }
        accuracies.push_back(static_cast<double>(correct) / foldTest.size());
    }

    meanAccuracy = myAccumulate(accuracies) / k;
    double variance = 0.0;
    for (double acc : accuracies) variance += std::pow(acc - meanAccuracy, 2);
    stdDev = std::sqrt(variance / k);

    std::cout << "10-Fold Cross-Validation Results:" << std::endl;
    for (int i = 0; i < k; ++i) {
        std::cout << "    Accuracy Fold " << i + 1 << ": " << std::fixed << std::setprecision(2) << accuracies[i] * 100 << "%" << std::endl;
    }
    std::cout << std::endl;
}

int main() {
    std::string filename = "house-votes-84.data";
    std::vector<Record> records;

    int input;
    std::string line;

    while (true) {
        std::getline(std::cin, line);  

        if (line.length() == 1 && (line[0] == '0' || line[0] == '1')) {
            input = line[0] - '0';  
            break;  
        }
        else {
            std::cout << "Invalid input. Please enter 0 or 1. "; 
        }
    }

    readData(filename, input, records);  

    std::vector<Record> train, test;
    stratifiedSplit(records, train, test, 0.8);

    double probabilities[NUM_CLASSES][NUM_ATTRIBUTES][3], classProbabilities[NUM_CLASSES];
    trainNaiveBayes(train, probabilities, classProbabilities, 1.0); 

    int correctTrain = 0;
    for (const auto& record : train) {
        if (predict(record, probabilities, classProbabilities) == record.classLabel) correctTrain++;
    }
    std::cout << std::endl << "1. Train Set Accuracy:" << std::endl;
    std::cout << "   Accuracy: " << std::fixed << std::setprecision(2) << (static_cast<double>(correctTrain) / train.size()) * 100 << "%" << std::endl << std::endl;

    double meanAccuracy, stdDev;
    crossValidation(train, 10, meanAccuracy, stdDev);
    std::cout << "    Average Accuracy: " << std::fixed << std::setprecision(2) << meanAccuracy * 100 << "%" << std::endl;
    std::cout << "    Standard Deviation: " << std::fixed << std::setprecision(2) << stdDev * 100 << "%" << std::endl << std::endl;

    int correctTest = 0;
    for (const auto& record : test) {
        if (predict(record, probabilities, classProbabilities) == record.classLabel) correctTest++;
    }
    std::cout << "2. Test Set Accuracy:" << std::endl;
    std::cout << "   Accuracy: " << std::fixed << std::setprecision(2) << (static_cast<double>(correctTest) / test.size()) * 100 << "%" << std::endl;

    return 0;
}
