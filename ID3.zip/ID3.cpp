#include <iostream>
#include <fstream>
#include <sstream>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <queue>
#include <algorithm>
#include <ctime>
#include <iomanip>
#include <cmath>

using namespace std;

vector<vector<string>> alldata;
vector<unordered_set<string>> allValues;
int minSampleSize = 50;

struct Node {
    bool isRec;
    bool isLeaf = false;
    int errors = 0;
    int attribute;
    string value;
    Node* parent = nullptr;
    vector<Node*> children;
    unordered_set<int> prevAttributes;
};

struct DataSet {
    vector<vector<string>> rows;
    vector<unordered_set<string>> attrValues;
    unordered_map<string, int> table[2][10];

    int datasize;
    int noRecSize = 0;
    int recSize = 0;

    DataSet(vector<vector<string>> rows) {
        this->rows = rows;
        getAttrValuesFromRows();
        fromRowsToTable();
    }

    void getAttrValuesFromRows() {
        attrValues.resize(10);
        for (int i = 0; i < rows.size(); i++) {
            for (int j = 1; j < rows[i].size(); j++) {
                attrValues[j].insert(rows[i][j]);
            }
        }
    }

    void fromRowsToTable() {
        bool isRec;
        for (int i = 0; i < rows.size(); i++) {
            for (int j = 0; j < rows[i].size(); j++) {
                if (j == 0) {
                    isRec = rows[i][j][0] == 'r';
                    isRec ? recSize++ : noRecSize++;
                }
                else {
                    table[isRec][j][rows[i][j]]++;
                }
            }
        }
        datasize = recSize + noRecSize;
    }

    double entropy(double a, double b) {
        if (a == 0 || b == 0) {
            return 0;
        }
        double pa = a / (a + b);
        double pb = b / (a + b);
        return -(pa)*log2(pa) - (pb)*log2(pb);
    }

    double entropyAttr(int attrIndex) {
        string key;
        double entr = 0;
        double noRec, rec;
        for (auto it = table[0][attrIndex].begin(); it != table[0][attrIndex].end(); ++it) {
            key = it->first;
            noRec = it->second;
            rec = table[1][attrIndex][key];
            entr += ((noRec + rec) / datasize) * entropy(noRec, rec);
        }
        return entr;
    }

    double infoGain(int attrIndex) {
        return entropy(noRecSize, recSize) - entropyAttr(attrIndex);
    }

    int findBestAttribute(unordered_set<int> prevAttributes) {
        double maxInfoGain = INT_MIN;
        double curInfoGain;
        int bestAttr = 1;

        for (int curAttr = 1; curAttr < 10; curAttr++) {
            if (prevAttributes.find(curAttr) == prevAttributes.end()) {
                curInfoGain = infoGain(curAttr);
                if (curInfoGain > maxInfoGain) {
                    maxInfoGain = curInfoGain;
                    bestAttr = curAttr;
                }
            }
        }
        return bestAttr;
    }

    DataSet* filter(int attr, string value) {
        vector<vector<string>> newRows;
        for (int i = 0; i < rows.size(); i++) {
            if (value.compare(rows[i][attr]) == 0) {
                newRows.push_back(rows[i]);
            }
        }
        return new DataSet(newRows);
    }

    bool isRecMoreCommon(Node* node) {
        return recSize > noRecSize;
    }
};

struct DecisionTree {
    Node* root;

    void buildAttributeNode(DataSet* dataset, Node* parentNode) {
        Node* childNode;
        if (parentNode == nullptr) {
            root = new Node();
            childNode = root;
        }
        else {
            childNode = new Node();
            childNode->prevAttributes = parentNode->prevAttributes;
            parentNode->children.push_back(childNode);
        }
        int bestAttr = dataset->findBestAttribute(childNode->prevAttributes);
        childNode->attribute = bestAttr;
        childNode->prevAttributes.insert(bestAttr);
        childNode->parent = parentNode;
        childNode->isRec = dataset->isRecMoreCommon(childNode);

        unordered_set<string> attrValues = allValues[bestAttr];
        for (string value : attrValues) {
            buildValueNode(bestAttr, value, childNode, dataset);
        }
    }

    virtual void buildValueNode(int attr, string value, Node* parentNode, DataSet* dataset) = 0;

    bool classify(vector<string> row) {
        int attr;
        string value;
        Node* node = root;
        while (true) {
            attr = node->attribute;
            value = row[attr];

            for (int i = 0; i < node->children.size(); i++) {
                if (value.compare(node->children[i]->value) == 0) {
                    if (node->children[i]->isLeaf) {
                        return (node->children[i]->isRec) ? row[0].compare("recurrence-events") == 0 : row[0].compare("no-recurrence-events") == 0;
                    }
                    node = node->children[i]->children[0];
                    break;
                }
            }
        }
    }

    bool isEntropyZero(DataSet* dataset) {
        return dataset->entropy(dataset->recSize, dataset->noRecSize) == 0;
    }
};

struct DecisionTreePrePruning : public DecisionTree {
    DecisionTreePrePruning(DataSet* dataset) {
        buildAttributeNode(dataset, nullptr);
    }

    void buildValueNode(int attr, string value, Node* parentNode, DataSet* dataset) {
        if (isEntropyZero(dataset) || parentNode->prevAttributes.size() == 9 || dataset->rows.size() < minSampleSize) {
            Node* leaf = new Node();
            leaf->value = value;
            leaf->isLeaf = true;
            leaf->parent = parentNode;
            leaf->isRec = dataset->isRecMoreCommon(leaf);
            parentNode->children.push_back(leaf);
            return;
        }
        Node* childNode = new Node();
        childNode->attribute = attr;
        childNode->value = value;
        childNode->prevAttributes = parentNode->prevAttributes;
        childNode->parent = parentNode;
        childNode->isRec = dataset->isRecMoreCommon(childNode);
        parentNode->children.push_back(childNode);
        DataSet* subset = dataset->filter(attr, value);
        buildAttributeNode(subset, childNode);
        delete subset;
    }
};

struct DecisionTreePostPruning : public DecisionTree {
    vector<vector<string>> validationset;

    DecisionTreePostPruning(DataSet* dataset) {
        auto splitData = stratifiedSplit(dataset);
        DataSet* trainSet = splitData.first;
        validationset = splitData.second;

        buildAttributeNode(trainSet, nullptr);
    }

    pair<DataSet*, vector<vector<string>>> stratifiedSplit(DataSet* dataset) {
        vector<vector<string>> trainRows;
        vector<vector<string>> validRows;

        int validSize = dataset->rows.size() / 10;
        int trainingSize = dataset->rows.size() - validSize;

        for (int i = 0; i < dataset->rows.size(); i++) {
            if (i < trainingSize) {
                trainRows.push_back(dataset->rows[i]);
            }
            else {
                validRows.push_back(dataset->rows[i]);
            }
        }

        return { new DataSet(trainRows), validRows };
    }

    void buildValueNode(int attr, string value, Node* parentNode, DataSet* dataset) {
        if (isEntropyZero(dataset) || parentNode->prevAttributes.size() == 9 || dataset->rows.size() < minSampleSize) {
            Node* leaf = new Node();
            leaf->value = value;
            leaf->isLeaf = true;
            leaf->parent = parentNode;
            leaf->isRec = dataset->isRecMoreCommon(leaf);
            parentNode->children.push_back(leaf);
            return;
        }

        Node* childNode = new Node();
        childNode->attribute = attr;
        childNode->value = value;
        childNode->prevAttributes = parentNode->prevAttributes;
        childNode->parent = parentNode;
        childNode->isRec = dataset->isRecMoreCommon(childNode);
        parentNode->children.push_back(childNode);

        DataSet* subset = dataset->filter(attr, value);
        buildAttributeNode(subset, childNode);
        delete subset;
    }

    double validate() {
        double errors = 0;
        for (const auto& row : validationset) {
            if (!classify(row)) {
                errors++;
            }
        }
        return errors / validationset.size();
    }

    void postPrune(Node* node) {
        if (node->isLeaf) {
            return;
        }

        for (Node* child : node->children) {
            postPrune(child);
        }

        double errorBeforePrune = validate();
        node->isLeaf = true;
        double errorAfterPrune = validate();

        if (errorBeforePrune <= errorAfterPrune) {
            node->isLeaf = false;
        }
    }

    void pruneTree() {
        postPrune(root);
    }
};

void readFromFile() {
    string line, attribute;
    ifstream filein("breast-cancer.data", ios::in);
    allValues.resize(10);
    int counter = 0;
    while (getline(filein, line)) {
        stringstream ss(line);
        vector<string> attributes;
        while (getline(ss, attribute, ',')) {
            attributes.push_back(attribute);
            allValues[counter].insert(attribute);
            counter++;
        }
        alldata.push_back(attributes);
        counter = 0;
    }
    std::srand(unsigned(std::time(0)));
    random_shuffle(alldata.begin(), alldata.end());
    filein.close();
}

double calculateStandardDeviation(const vector<double>& accuracies) {
    double sum = 0.0;
    double mean = 0.0;
    for (size_t i = 0; i < accuracies.size(); i++) {
        sum += accuracies[i];
    }
    mean = sum / accuracies.size();
    double variance = 0.0;
    for (size_t i = 0; i < accuracies.size(); i++) {
        variance += std::pow(accuracies[i] - mean, 2);
    }
    variance /= accuracies.size();
    return std::sqrt(variance);
}

void stratifiedSplit(vector<vector<string>>& dataset, vector<vector<string>>& trainSet, vector<vector<string>>& testSet) {
    int testSize = dataset.size() * 20 / 100; 
    int trainSize = dataset.size() - testSize; 

    for (int i = 0; i < dataset.size(); i++) {
        if (i < trainSize) {
            trainSet.push_back(dataset[i]);
        }
        else {
            testSet.push_back(dataset[i]);
        }
    }
}

double calculateTrainAccuracy(vector<vector<string>>& trainset, int mode) {
    DataSet* trainDataSet = new DataSet(trainset);
    DecisionTree* tree;

    if (mode == 0) {
        tree = new DecisionTreePrePruning(trainDataSet);
    }
    else {
        tree = new DecisionTreePostPruning(trainDataSet);
    }

    int correctCount = 0;
    for (auto& row : trainset) {
        if (tree->classify(row)) {
            correctCount++;
        }
    }
    return static_cast<double>(correctCount) / trainset.size() * 100;
}

double calculateAccuracyTestSet(vector<vector<string>>& trainset, vector<vector<string>>& testset, int mode) {
    DataSet* testDataSet = new DataSet(testset);
    DecisionTree* tree;

    if (mode == 0) {
        tree = new DecisionTreePrePruning(testDataSet);
    }
    else {
        tree = new DecisionTreePostPruning(testDataSet);
    }

    int correctCount = 0;
    for (auto& row : testset) {
        if (tree->classify(row)) {
            correctCount++;
        }
    }
    return static_cast<double>(correctCount) / testset.size() * 100;
}

void tenFoldCrossValidate(int mode) {
    vector<double> accuracies;
    vector<vector<string>> shuffledData = alldata;

    std::srand(unsigned(std::time(0)));
    random_shuffle(shuffledData.begin(), shuffledData.end());

    int foldSize = shuffledData.size() / 10;
    for (int i = 0; i < 10; i++) {
        vector<vector<string>> trainset, testset;

        int start = i * foldSize;
        int end = (i == 9) ? shuffledData.size() : (i + 1) * foldSize;

        for (int j = start; j < end; j++) {
            testset.push_back(shuffledData[j]);
        }

        for (int j = 0; j < shuffledData.size(); j++) {
            if (j < start || j >= end) {
                trainset.push_back(shuffledData[j]);
            }
        }

        double accuracy = (mode == 0)
            ? calculateTrainAccuracy(trainset, mode)
            : calculateAccuracyTestSet(trainset, testset, mode);

        accuracies.push_back(accuracy);
    }

    double meanAccuracy = 0;
    for (double acc : accuracies) {
        meanAccuracy += acc;
    }
    meanAccuracy /= accuracies.size();

    double stdDev = calculateStandardDeviation(accuracies);

    cout << "10-Fold Cross-Validation Results:" << endl;
    for (int i = 0; i < 10; i++) {
        cout << "   Accuracy Fold " << i + 1 << ": " << fixed << setprecision(2) << accuracies[i] << "%" << endl;
    }

    cout << endl;
    cout << "   Average Accuracy: " << fixed << setprecision(2) << meanAccuracy << "%" << endl;
    cout << "   Standard Deviation: " << fixed << setprecision(2) << stdDev << "%" << endl << endl;
}

int main() {
    int mode;
    cout << "Enter 0 for pre-pruning or 1 for post-pruning. ";
    cin >> mode;

    readFromFile();

    vector<vector<string>> trainset;
    vector<vector<string>> testset;
    stratifiedSplit(alldata, trainset, testset);

    double trainAccuracy = calculateTrainAccuracy(trainset, mode);
    double testAccuracy = calculateAccuracyTestSet(trainset, testset, mode);

    cout << endl << "1. Train Set Accuracy:" << endl << "   Accuracy: " << fixed << setprecision(2) << trainAccuracy << "%" << endl << endl;

    tenFoldCrossValidate(mode);

    cout << "2. Test Set Accuracy:" << endl << "   Accuracy: " << fixed << setprecision(2) << testAccuracy << "%" << endl;

    return 0;
}
